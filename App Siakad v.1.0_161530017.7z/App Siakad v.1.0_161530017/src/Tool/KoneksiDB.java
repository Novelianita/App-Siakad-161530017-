/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tool;

import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author DEVI
 */
public class KoneksiDB {
    
    public Connection getConnection() throws SQLException{ 
        Connection cnn; 
        try{
            String server = "jdbc:mysql://localhost/dbsiakadv1_161530017"; 
            String drever = "com.mysql.jdbc.Driver"; 
            Class.forName(drever); 
            cnn = DriverManager.getConnection(server, "root", ""); 
            return cnn;
            
        }catch(SQLException | ClassNotFoundException se){ 
            JOptionPane.showMessageDialog(null, "error koneksi database : "+ se);
            return null;
        }
    }
}
